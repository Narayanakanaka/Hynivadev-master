declare module "@salesforce/apex/AccountController.findAccounts" {
  export default function findAccounts(param: {searchKey: any}): Promise<any>;
}
